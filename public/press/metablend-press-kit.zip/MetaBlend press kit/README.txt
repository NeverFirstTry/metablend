MetaBlend press kit

MetaBlend is a free weather app that blends up to 20 weather sources into one forecast and shows how far they agree. Each source counts for more where it has been close lately, checked against weather stations, airport reports and feedback from people on the ground. For the mountains it adds summit forecasts, the best window for a summit and hiking routes timed against the weather.

Key facts
Sources: Up to 20 weather models and services, among them ECMWF, GFS, ICON, MET Norway and the NWS
Languages: 13
Platforms: The web at metablend.app, iPhone and Android
Price: Free, no ads, no account
Made by: One developer in Lienz, in the Austrian Alps
Launch: 15 December 2026 on the App Store and Google Play

Press contact: info@metablend.app
https://metablend.app/press

* Logo: the wordmark and the MB mark, for light and dark backgrounds, as SVG and PNG
* App icon in Slate, as SVG and PNG
* Five screenshots each for the App Store and Google Play, in English
* Three app screenshots without captions
* The Google Play feature graphic

Everything in one ZIP file. Free to use when you report on MetaBlend.


MetaBlend Pressemappe

MetaBlend ist eine kostenlose Wetter-App, die bis zu 20 Wetterquellen zu einer Vorhersage verbindet und zeigt, wie einig sie sich sind. Jede Quelle zählt dort mehr, wo sie zuletzt richtig lag, geprüft an Wetterstationen, Flughafenmeldungen und Rückmeldungen von Menschen vor Ort. Für die Berge kommen Gipfelprognosen, das beste Zeitfenster für einen Gipfel und Wanderrouten mit Zeitplan nach dem Wetter dazu.

Fakten
Quellen: Bis zu 20 Wettermodelle und Wetterdienste, darunter ECMWF, GFS, ICON, MET Norway und der NWS
Sprachen: 13
Plattformen: Im Web auf metablend.app, iPhone und Android
Preis: Kostenlos, ohne Werbung, ohne Konto
Entwicklung: Ein Entwickler in Lienz, in den österreichischen Alpen
Start: 15. Dezember 2026 im App Store und bei Google Play

Pressekontakt: info@metablend.app
https://metablend.app/press

* Logo: der Schriftzug und das MB-Zeichen, für helle und dunkle Hintergründe, als SVG und PNG
* App-Symbol in Slate, als SVG und PNG
* Je fünf Screenshots für den App Store und Google Play, auf Englisch
* Drei App-Screenshots ohne Beschriftung
* Die Feature-Grafik für Google Play

Alles in einer ZIP-Datei. Frei verwendbar für Berichte über MetaBlend.
